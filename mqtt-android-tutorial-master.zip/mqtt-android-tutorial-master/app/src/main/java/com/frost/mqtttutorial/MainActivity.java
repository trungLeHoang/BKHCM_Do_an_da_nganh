package com.frost.mqtttutorial;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.github.mikephil.charting.charts.LineChart;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.nio.charset.Charset;

import helpers.ChartHelper;
import helpers.MqttHelper;

public class MainActivity extends AppCompatActivity {

    MqttHelper mqttHelper;
    LineChart chart;

    TextView temp, humid;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        temp = (TextView) findViewById(R.id.temp);
        humid = (TextView) findViewById(R.id.humid);
        startMqtt();
    }

    private void startMqtt(){
        mqttHelper = new MqttHelper(getApplicationContext());
        mqttHelper.mqttAndroidClient.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean b, String s) {
                Log.w("Debug","Connected");
            }

            @Override
            public void connectionLost(Throwable throwable) {

            }

            @Override
            public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
                String msg, stemp, shumid;
                int isep;
                msg = mqttMessage.toString();
                isep = msg.indexOf('-');
                stemp = msg.substring(0, isep) + "°C";
                shumid = msg.substring(isep + 1, msg.length()) + '%';
                Log.w("Debug",mqttMessage.toString());
                temp.setText(stemp);
                humid.setText(shumid);
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {

            }
        });
    }
//
//    private void publishMQTT (String data) {
//        MqttMessage msg = new MqttMessage();
//        msg.setId(1234);
//        msg.setQos(0);
//        msg.setRetained(true);
//
//        byte[] b = data.getBytes(Charset.forName("UTF-8"));
//        msg.setPayload(b);
//
//        Log.d("ABC","Publish" + msg);
//        try {
//            mqttHelper.mqttAndroidClient.publish("bkdadn/feeds/bk-iot-temp-humid", msg);
//        } catch (MqttException e) {
//
//        }
//
//
//    }
}
